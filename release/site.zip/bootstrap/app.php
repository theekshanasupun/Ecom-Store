<?php

use App\Http\Middleware\Admin;
use App\Http\Middleware\EnsureInstalled;
use App\Http\Middleware\Maintenance;
use App\Http\Middleware\Staff;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->trustProxies(at: '*');
        $middleware->validateCsrfTokens(except: ['pay/stripe/webhook']);
        $middleware->web(prepend: [EnsureInstalled::class], append: [Maintenance::class]);
        $middleware->alias(['staff' => Staff::class, 'admin' => Admin::class]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn (Request $request) => $request->expectsJson());
    })->create();
